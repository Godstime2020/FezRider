import {StyleProp, Text, TextStyle} from 'react-native';

type AppTextProps = {
  children: React.ReactNode;
  style?: StyleProp<TextStyle>;
  fontWeight?: '200' | '300' | '400' | '500' | '600' | '700';
};

const AppText: React.FC<AppTextProps> = ({children, style, fontWeight = '400'}) => {
  let customFontFamily = 'Onest-Regular'; // default

  switch (fontWeight) {
    case '200':
      customFontFamily = 'Onest-ExtraLight';
      break;
    case '300':
      customFontFamily = 'Onest-Light';
      break;
    case '400':
      customFontFamily = 'Onest-Regular';
      break;
    case '500':
      customFontFamily = 'Onest-Medium';
      break;
    case '600':
      customFontFamily = 'Onest-SemiBold';
      break;
    case '700':
      customFontFamily = 'Onest-Bold';
      break;
    default:
      break;
  }
  return <Text style={[{fontFamily: customFontFamily}, style]}>{children}</Text>;
};

export {AppText};
