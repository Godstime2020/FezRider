import React, {useState, useEffect, forwardRef, useImperativeHandle} from 'react';
import {View, StyleSheet, StyleProp, ViewStyle, TextStyle, Text} from 'react-native';
import {AppText} from './AppText';
import colors from '../constant/colors';

type CountdownProps = {
  minutes: number;
  onEnd?: () => void;
  style?: StyleProp<ViewStyle>;
  TextStyle?: StyleProp<TextStyle>;
};

const Countdown = forwardRef(({minutes, onEnd, style, TextStyle}: CountdownProps, ref) => {
  const [timeLeft, setTimeLeft] = useState(minutes * 60); // convert minutes to seconds

  useEffect(() => {
    if (!timeLeft) {
      onEnd && onEnd();
      return;
    }

    const intervalId = setInterval(() => {
      setTimeLeft(timeLeft - 1);
    }, 1000);

    return () => clearInterval(intervalId);
  }, [timeLeft, onEnd]);

  const displayMinutes = Math.floor(timeLeft / 60);
  const displaySeconds = timeLeft % 60;

  // Reset function
  const resetCountdown = () => {
    setTimeLeft(minutes * 60);
  };

  // Expose the resetCountdown method to parent via ref
  useImperativeHandle(ref, () => ({
    resetCountdown,
  }));

  // Conditionally update styles based on timeLeft
  const containerStyle =
    timeLeft === 0 ? [styles.container, styles.endContainer, style] : [styles.container, style];
  const TextStyles =
    timeLeft === 0 ? [styles.Text, styles.endText, TextStyle] : [styles.Text, TextStyle];

  return (
    <View style={containerStyle}>
      <AppText fontWeight="700" style={TextStyles}>
        {`${displayMinutes}:${displaySeconds < 10 ? '0' + displaySeconds : displaySeconds}`}
      </AppText>
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    padding: 10,
    backgroundColor: '#AFD6AA', // Initial background color
    borderRadius: 50,
    alignItems: 'center',
    alignSelf: 'center',
    marginTop: 40,
  },
  endContainer: {
    backgroundColor: '#EC330A', // Background color for 0:00
  },
  Text: {
    fontSize: 12,
    color: colors.midnightBlueColor, // Initial Text color
  },
  endText: {
    color: '#FFFFFF', // Text color for 0:00
  },
});

export {Countdown};
