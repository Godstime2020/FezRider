export type RootStackParamList = {
  Login: undefined;
  ForgotPassword: undefined;
  CreateNewPassword: undefined;
  Dashboard: undefined; // nested tabNavigator
  Home: undefined;
};

export type WeightItem = {
  id: number;
  name: string;
};

export type ZoneItem = {
  id: number;
  name: string;
  location: [];
};

type Country = {
  id: number;
  name: string;
  code: string;
  flag: any;
};

type Currency = {
  code: string;
  id: number;
  name: string;
  symbol: string;
};

type address = {
  id: number;
  address: string;
};

export type importLocationItem = {
  id: number;
  proof: number;
  country: Country;
  currency: Currency;
  postCode: string;
  addresses: address[];
  city: string;
  state: string;
};

export type ItemCategory = {
  id: number;
  name: string;
  deleted_at: any;
  created_at: string;
  updated_at: string;
};
