
// Define an interface for our color palette
interface ColorPalette {
  gradientForm: string;
  primary: string;
  white: string;
  dark: string;
  bgColor: string;
  warning: string;
  danger: string;
  gray: string;
  grayLight: string;
  black: string;
  btnColor: string;
  appPrimaryColor: string;
  midnightBlueColor: string;
  offWhite: string;
  darkGray: string;
  lightGray: string;
  lightBlueGray: string;
  grayishGreen: string;
  deepRed: string;
  lightPink: string;
  orangeRed: string;
  mediumDarkGray: string;
  lightYellow: string;
  lightGreen: string;
  mediumGray: string;
}

// Create our color palette object with the correct type
const colors: ColorPalette = {
  gradientForm: '#72b8f8',
  primary: '#0598ce',
  white: '#FFFFFF',
  dark: '#444444',
  bgColor: '#82ccdd',
  warning: '#f0d500',
  danger: '#FF0D0E',
  gray: '#666666',
  grayLight: '#cccccc',
  black: '#0a0a0a',
  btnColor: '#289D17',
  appPrimaryColor: "#18AF04",
  midnightBlueColor: "#071227",
  offWhite: "#F4F5F6",
  darkGray: "#4E4F55",
  lightGray: "#EAEEE8",
  lightBlueGray: "#BAC0CF",
  grayishGreen: "#A4AFA2",
  deepRed: "#AA2407",
  lightPink: "#FFE4E0",
  orangeRed: "#EC330A",
  mediumDarkGray: "#686868",
  lightYellow: "#FFF9E8",
  lightGreen: "#F0FDEE",
  mediumGray: "#686868",
};

// Export the color palette
export default colors;