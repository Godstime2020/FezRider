type ImageSource = ReturnType<typeof require>;
interface Images {
  helmet: ImageSource;
  password: ImageSource;
  forgotPassword: ImageSource;
  pickUpIcon: ImageSource;
  helmetIcon: ImageSource;
  barcodeScanner: ImageSource;
  inbox: ImageSource;
}

// Create our images object with the correct type
const images: Images = {
  helmet: require('../assets/images/helmet.png'),
  password: require('../assets/images/password.png'),
  forgotPassword: require('../assets/images/forgot-password.png'),
  pickUpIcon: require('../assets/images/pick-up-icon.png'),
  helmetIcon: require('../assets/images/helmet-icon.png'),
  barcodeScanner: require('../assets/images/barcode-scanner.png'),
  inbox: require('../assets/images/inbox.png'),
};

export default images;
