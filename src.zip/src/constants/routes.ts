const Routes = {
  LOGIN: 'Login',
  FORGOT_PASSWORD: 'ForgotPassword',
  CREATE_NEW_PASSWORD: 'CreateNewPassword',
  DASHBOARD: 'Dashboard',
} as const;

export default Routes;
