
import COLORS from './colors';
import ROUTES from './routes';
import IMAGES from './images';


export {ROUTES, IMAGES,COLORS};
