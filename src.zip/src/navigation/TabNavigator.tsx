import React from 'react';
import {Image, ImageSourcePropType, Platform} from 'react-native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';

import {Home, MyAccount} from '../screens';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Icon from 'react-native-remix-icon';
import {COLORS} from '../constants';

// Define the props for our tab navigation component
// interface TabNavigationProps {
//   Home: React.ComponentType<any>;
//   Account: React.ComponentType<any>;
//   firstTabLabel?: string;
//   secondTabLabel?: string;
//   firstTabIcon: ImageSourcePropType;
//   secondTabIcon: ImageSourcePropType;
// }

type TabIconProps = {
  focused: boolean;
  color: string;
  size?: number;
  route: any;
};

const Tab = createBottomTabNavigator();

const TabNavigation: React.FC = ({}) => {
  /**
   * Renders the icon for the tab bar.
   * @param {TabIconProps} props - The props for the component.
   * @returns {JSX.Element} The rendered icon component.
   */
  const renderTabBarIcon = ({
    focused,
    color,
    size = 27,
    route,
  }: TabIconProps): JSX.Element => {
    let iconName = '';
    if (route.name === 'Home') {
      iconName = 'home-4-fill';
    } else if (route.name === 'MyAccount') {
      iconName = 'account-box-fill';
    }
    return <Icon name={iconName} size={size} color={color} focused={focused} />;
  };

  return (
    <Tab.Navigator
      initialRouteName="Home"
      screenOptions={({route}) => ({
        tabBarIcon: ({focused, color, size}) =>
          renderTabBarIcon({focused, color, size, route}),
        tabBarActiveTintColor: COLORS.appPrimaryColor,
        tabBarInactiveTintColor: '#C3C3C3',
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: {
          paddingTop: 10,
          paddingBottom: Platform.OS === 'ios' ? 20 : 10,
          height: hp(7),
          marginHorizontal: 15,
          marginBottom: 20,
          borderColor: '#E3E3E3',
          borderWidth: 1,
          borderBottomLeftRadius: 30,
          borderBottomRightRadius: 30,
          borderTopRightRadius: 10,
          borderTopLeftRadius: 10,
          elevation: 0.3,
        },
      })}>
      <Tab.Screen name={'Home'} component={Home} />
      <Tab.Screen name={'MyAccount'} component={MyAccount} />
    </Tab.Navigator>
  );
};

export default TabNavigation;
