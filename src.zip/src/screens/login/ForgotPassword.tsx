import React, {useRef, useState} from 'react';
import {
  Text,
  SafeAreaView,
  StyleSheet,
  Image,
  TextInput,
  View,
  TouchableOpacity,
} from 'react-native';
import {COLORS} from '../../constants';
// import OTPTextView from 'react-native-otp-Textinput';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';

const ForgotPassword = (): JSX.Element => {
  const [identifier, setIdentifier] = useState<string>(''); // For phone number or email

  const isButtonEnabled: boolean = identifier.trim() !== '';

  const handleForgotPassword = (): void => {
    // Handle form submission logic here
    console.log('Identifier:', identifier);
  };

  return (
    <SafeAreaView style={styles.safeAreaView}>
      <KeyboardAwareScrollView>
        <View style={styles.imgContainer}>
          <Image
            source={require('../../assets/images/forgot-password.png')}
            resizeMode="cover"
          />
        </View>
        <Text style={{fontWeight: '900', marginBottom: 20}}>
          Forgot password
        </Text>
        <Text style={{fontSize: 12, marginBottom: 20}}>
          Reset your password with your registered email or phone number
        </Text>
        <View style={{flex: 1}}>
          <TextInput
            style={styles.input}
            placeholder="Enter your email or phone number"
            value={identifier}
            onChangeText={setIdentifier}
            autoCapitalize="none"
          />
        </View>

        <TouchableOpacity
          style={[
            styles.button,
            isButtonEnabled ? styles.buttonEnabled : styles.buttonDisabled,
          ]}
          onPress={handleForgotPassword}
          disabled={!isButtonEnabled} // Disable the button if not
        >
          <Text style={{color: isButtonEnabled ? COLORS.white : COLORS.gray}}>
            Continue
          </Text>
        </TouchableOpacity>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeAreaView: {
    flex: 1,
    backgroundColor: COLORS.offWhite,
    padding: 20,
  },
  imgContainer: {
    marginVertical: 80,
    justifyContent: 'center', // Centers content vertically
    alignItems: 'flex-start', // Centers content horizontally
  },
  label: {
    marginBottom: 8,
    fontSize: 14,
  },
  input: {
    height: 50,
    borderColor: COLORS.grayLight,
    borderWidth: 1,
    borderRadius: 7,
    paddingHorizontal: 10,
    marginBottom: 35,
  },
  button: {
    height: 50,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 120,
  },
  buttonEnabled: {
    backgroundColor: 'green', // Green color when enabled
  },
  buttonDisabled: {
    backgroundColor: 'lightgray', // Gray color when disabled
  },
  buttonText: {
    color: COLORS.gray,
    fontSize: 16,
  },
});

export default ForgotPassword;
