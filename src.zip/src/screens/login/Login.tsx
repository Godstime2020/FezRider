import * as React from 'react';
import {
  Text,
  SafeAreaView,
  StyleSheet,
  Image,
  TextInput,
  View,
  TouchableOpacity,
} from 'react-native';
import {COLORS, IMAGES, ROUTES} from '../../constants';
import {StackNavigationProp} from '@react-navigation/stack';
import {RootStackParamList} from '../../utils/types';
import {AppText} from '../../components/AppText';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';

type LoginNavigationProp = StackNavigationProp<RootStackParamList, 'Login'>;
type Props = {navigation: LoginNavigationProp};

const Login: React.FC<Props> = ({navigation}) => {
  const [identifier, setIdentifier] = React.useState<string>(''); // For phone number or email
  const [password, setPassword] = React.useState<string>('');

  const isButtonEnabled = identifier.trim() !== '' && password.trim() !== '';
  const handleForgotPassword = () => {
    // Handle form submission logic here
    console.log('Identifier:', identifier);
    console.log('Password:', password);
    navigation.navigate(ROUTES.FORGOT_PASSWORD);
  };
  const handleLogin = () => {
    // Handle form submission logic here
    console.log('Identifier:', identifier);
    console.log('Password:', password);
    navigation.navigate(ROUTES.DASHBOARD);
  };

  return (
    <SafeAreaView style={styles.safeAreaView}>
      <KeyboardAwareScrollView>
        <View style={styles.imgContainer}>
          <Image source={IMAGES.helmet} resizeMode="cover" />
        </View>
        <View style={{flex: 1}}>
          <AppText style={styles.label}>
            Enter Phone Number or Email Address
          </AppText>
          <TextInput
            style={styles.input}
            placeholder="Enter your email or phone number"
            value={identifier}
            onChangeText={setIdentifier}
            autoCapitalize="none"
          />

          <AppText style={styles.label}>Password</AppText>
          <TextInput
            style={styles.input}
            placeholder="Enter your password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
          <TouchableOpacity onPress={handleForgotPassword}>
            <Text style={{color: COLORS.btnColor, fontWeight: '900'}}>
              Forgot password?
            </Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity
          style={[
            styles.button,
            isButtonEnabled ? styles.buttonEnabled : styles.buttonDisabled,
          ]}
          onPress={handleLogin}
          disabled={!isButtonEnabled} // Disable the button if not
        >
          <AppText
            style={{color: isButtonEnabled ? COLORS.white : COLORS.gray}}>
            Login
          </AppText>
        </TouchableOpacity>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeAreaView: {
    flex: 1,
    backgroundColor: COLORS.offWhite,
    padding: 20,
  },
  imgContainer: {
    marginVertical: 80,
    justifyContent: 'center', // Centers content vertically
    alignItems: 'center', // Centers content horizontally
  },
  label: {
    marginBottom: 8,
    fontSize: 14,
  },
  input: {
    height: 50,
    borderColor: COLORS.grayLight,
    borderWidth: 1,
    borderRadius: 7,
    paddingHorizontal: 10,
    marginBottom: 35,
  },
  button: {
    height: 50,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 80,
  },
  buttonEnabled: {
    backgroundColor: 'green', // Green color when enabled
  },
  buttonDisabled: {
    backgroundColor: 'lightgray', // Gray color when disabled
  },
  buttonText: {
    color: COLORS.gray,
    fontSize: 16,
  },
});

export default Login;
