import React, {useRef, useState} from 'react';
import {
  Text,
  SafeAreaView,
  StyleSheet,
  Image,
  TextInput,
  View,
  TouchableOpacity,
} from 'react-native';
import {COLORS} from '../../constants';
// import OTPTextView from 'react-native-otp-Textinput';
import {AppText} from '../../components/AppText';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
// import helmet from ''

const Login = (): JSX.Element => {
  const [identifier, setIdentifier] = useState<string>(''); // For phone number or email
  const [password, setPassword] = useState<string>('');
  const [ConfirmPassword, setConfirmPassword] = useState<string>('');

  const isButtonEnabled: boolean = identifier.trim() !== '';

  const handleCreateNewPassword = (): void => {
    // Handle form submission logic here
    console.log('Identifier:', identifier);
  };

  return (
    <SafeAreaView style={styles.safeAreaView}>
      <KeyboardAwareScrollView>
        <View style={styles.imgContainer}>
          <Image
            source={require('../../assets/images/password.png')}
            resizeMode="cover"
          />
        </View>
        <AppText style={{fontWeight: '900', marginBottom: 20}}>
          Create new password
        </AppText>

        <View style={{flex: 1}}>
          <Text style={styles.label}>Password</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <Text style={styles.label}>Confirm Password</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your password"
            value={ConfirmPassword}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>

        <TouchableOpacity
          style={[
            styles.button,
            isButtonEnabled ? styles.buttonEnabled : styles.buttonDisabled,
          ]}
          onPress={handleCreateNewPassword}
          disabled={!isButtonEnabled} // Disable the button if not
        >
          <Text style={{color: isButtonEnabled ? COLORS.white : COLORS.gray}}>
            Continue
          </Text>
        </TouchableOpacity>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeAreaView: {
    flex: 1,
    backgroundColor: COLORS.offWhite,
    padding: 20,
  },
  imgContainer: {
    marginVertical: 80,
    justifyContent: 'center', // Centers content vertically
    alignItems: 'flex-start', // Centers content horizontally
  },
  label: {
    marginBottom: 8,
    fontSize: 14,
  },
  input: {
    height: 50,
    borderColor: COLORS.grayLight,
    borderWidth: 1,
    borderRadius: 7,
    paddingHorizontal: 10,
    marginBottom: 35,
  },
  button: {
    height: 50,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonEnabled: {
    backgroundColor: 'green', // Green color when enabled
  },
  buttonDisabled: {
    backgroundColor: 'lightgray', // Gray color when disabled
  },
  buttonText: {
    color: COLORS.gray,
    fontSize: 16,
  },
});

export default Login;
