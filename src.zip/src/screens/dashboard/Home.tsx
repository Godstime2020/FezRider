import * as React from 'react';
import {
  Text,
  SafeAreaView,
  StyleSheet,
  Image,
  TextInput,
  View,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import {COLORS, IMAGES, ROUTES} from '../../constants';
import {StackNavigationProp} from '@react-navigation/stack';
import {RootStackParamList} from '../../utils/types';
import {AppText} from '../../components/AppText';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';

type HomeNavigationProp = StackNavigationProp<RootStackParamList, 'Home'>;
type Props = {navigation: HomeNavigationProp};
type ImageSource = ReturnType<typeof require>;

interface CardComponentProps {
  imageSource: ImageSource;
  title: string;
  quantity: number;
}
const CardComponent: React.FC<CardComponentProps> = ({
  imageSource,
  title,
  quantity,
}) => {
  return (
    <View style={styles.card}>
      <Image source={imageSource} style={styles.image} />
      <View style={styles.content}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.description}>{quantity.toString()}</Text>
      </View>
    </View>
  );
};
const ColumnOrientedCardComponent: React.FC<CardComponentProps> = ({
  imageSource,
  title,
  quantity,
}) => {
  return (
    <View style={[styles.card, {flexDirection: 'column', width: '45%'}]}>
      <Image source={imageSource} style={styles.image} />
      <View style={styles.content}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.description}>{quantity.toString()}</Text>
      </View>
    </View>
  );
};

const Home: React.FC<Props> = ({navigation}) => {
  return (
    <SafeAreaView style={styles.safeAreaView}>
      <ScrollView>
        <View style={styles.header}>
          <View style={{flexDirection: 'row'}}>
            <Image source={IMAGES.helmetIcon} style={styles.helmetIcon} />
            <Text style={styles.greeting}>Hello, Adelakun</Text>
          </View>
          <View style={{flexDirection: 'row'}}>
            <Image source={IMAGES.barcodeScanner} style={styles.headerIcon} />
            <Image source={IMAGES.inbox} style={styles.headerIcon} />
          </View>

          {/* Add QR code and camera icons here */}
        </View>

        <Text style={styles.sectionTitle}>For You</Text>
        <CardComponent
          imageSource={IMAGES.pickUpIcon}
          title={'To pick-up'}
          quantity={100}
        />
        <CardComponent
          imageSource={IMAGES.pickUpIcon}
          title={'To deliver'}
          quantity={100}
        />
        <CardComponent
          imageSource={IMAGES.pickUpIcon}
          title={'To hub'}
          quantity={100}
        />
        <CardComponent
          imageSource={IMAGES.pickUpIcon}
          title={'Offline'}
          quantity={100}
        />

        <Text style={styles.sectionTitle}>Return Orders</Text>
        <CardComponent
          imageSource={IMAGES.pickUpIcon}
          title={'To pick-up'}
          quantity={100}
        />
        <CardComponent
          imageSource={IMAGES.pickUpIcon}
          title={'To deliver'}
          quantity={100}
        />

        <View style={styles.historySection}>
          <Text style={{fontSize: 16, fontWeight: 'bold'}}>History</Text>
          <View
            style={{backgroundColor: '#E5EFE4', borderRadius: 50, padding: 10}}>
            <Text style={{color: '#666'}}>Month: August</Text>
          </View>
        </View>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <ColumnOrientedCardComponent
            imageSource={IMAGES.pickUpIcon}
            title={'To pick-up'}
            quantity={100}
          />
          <ColumnOrientedCardComponent
            imageSource={IMAGES.pickUpIcon}
            title={'To pick-up'}
            quantity={100}
          />
        </View>

        <CardComponent
          imageSource={IMAGES.pickUpIcon}
          title={'Total earnings'}
          quantity={100000}
        />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeAreaView: {
    flex: 1,
    backgroundColor: COLORS.offWhite,
    padding: 20,
  },
  imgContainer: {
    marginVertical: 80,
    justifyContent: 'center', // Centers content vertically
    alignItems: 'center', // Centers content horizontally
  },
  label: {
    marginBottom: 8,
    fontSize: 14,
  },
  input: {
    height: 50,
    borderColor: COLORS.grayLight,
    borderWidth: 1,
    borderRadius: 7,
    paddingHorizontal: 10,
    marginBottom: 35,
  },
  button: {
    height: 50,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 80,
  },
  buttonEnabled: {
    backgroundColor: 'green', // Green color when enabled
  },
  buttonDisabled: {
    backgroundColor: 'lightgray', // Gray color when disabled
  },
  buttonText: {
    color: COLORS.gray,
    fontSize: 16,
  },
  card: {
    flexDirection: 'row',
    padding: 16,
    borderRadius: 8,
    backgroundColor: '#fff',
    elevation: 2, // For Android shadow
    shadowColor: '#000', // For iOS shadow
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.2,
    shadowRadius: 1,
    marginVertical: 8,
  },
  image: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 16,
  },
  headerIcon: {
    width: 20,
    height: 20,
    borderRadius: 8,
    marginRight: 10,
  },
  helmetIcon: {
    width: 30,
    height: 30,
    borderRadius: 8,
    marginRight: 10,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  description: {
    fontSize: 14,
    color: '#666',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderRadius: 8,
    backgroundColor: '#fff',
    elevation: 2, // For Android shadow
    shadowColor: '#000', // For iOS shadow
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.2,
    shadowRadius: 1,
  },
  greeting: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  historySection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 40,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 30,
    marginLeft: 16,
  },
});

export default Home;
