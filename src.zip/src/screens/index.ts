export {default as Login} from './login/Login';
export {default as ForgotPassword} from './login/ForgotPassword';
export {default as CreateNewPassword} from './login/CreateNewPassword';
export {default as Home} from './dashboard/Home';
export {default as MyAccount} from './dashboard/MyAccount';
